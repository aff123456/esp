### FSBrowser from the example of ESP8266WebServer

This example sketch is in ESP8266WebServer library for Arduino environment. The [FSWebServer](https://github.com/esp8266/Arduino/tree/master/libraries/ESP8266WebServer/examples/FSBrowser) is cited as an example of combining AutoConnect library.

The modification describes in the source code.

#### License

FSWebServer - Example WebServer with SPIFFS backend for esp8266  
Copyright (c) 2015 Hristo Gochkov. All rights reserved.  
This file is part of the ESP8266WebServer library for Arduino environment.

License under the LGPL-2.1.
